package com.xuancao.dynamicskin.ui;

import android.os.Bundle;

import com.xuancao.dynamicskin.R;
import com.xuancao.dynamicskin.base.SimpleBaseActivity;

/**
 * Created by Administrator on 2017/10/13.
 */

public class TestActivity extends SimpleBaseActivity{
    @Override
    protected void onActivityCreated(Bundle savedInstanceState) {
        setContentView(R.layout.activity_test);
    }

    @Override
    protected void initView() {

    }
}
