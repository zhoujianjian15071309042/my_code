package com.xuancao.dynamicskin.app;

/**
 * Created by xuancao on 2017/7/3.
 */

public interface Constant {

    int CLICK_INTERVAL = 800;
    /**
     * true 为debug状态，打印日志;false为关闭log状态
     */
    public static boolean IS_DEBUG = true;

    String SHARE_NAME = "xchuang_spf";
}
