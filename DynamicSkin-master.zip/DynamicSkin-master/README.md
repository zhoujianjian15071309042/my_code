# DynamicSkin
动态更换主题颜色风格，可通过滑动附有颜色带的progressbar来实现动态更改整体风格,项目中还有一些可以base类用于管理项目结构分层，如果有疑问，请联系xuancaocom@sina.cn  如果对您有帮助，给个star吧！

![image](https://github.com/xuancao/DynamicSkin/blob/master/screenshot/skinchange3.gif)

![image](https://github.com/xuancao/DynamicSkin/blob/master/screenshot/skinchange3.png)

博客地址 http://www.jianshu.com/p/dcc076de9192

参考：library参考https://github.com/cseshaiban/app-theme-engine-master中的依赖库
