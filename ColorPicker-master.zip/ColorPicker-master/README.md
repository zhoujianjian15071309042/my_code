仿网易云音乐皮肤选择自定义颜色的颜色调节控件

### 效果图

详情查看简书[仿网易云音乐之皮肤自选颜色](http://www.jianshu.com/p/8ba36619ab0a)

![效果图](image/xiaoguo.gif)