package com.onexzgj.skin.activity;

/**
 * des：
 * author：onexzgj
 * time：2019/1/15
 */
public class Constant {

    public static final String CURRENT_SKIN="CURRENT_SKIN";
}
