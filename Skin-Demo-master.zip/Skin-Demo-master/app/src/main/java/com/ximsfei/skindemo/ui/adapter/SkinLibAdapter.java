package com.ximsfei.skindemo.ui.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import com.ximsfei.skindemo.ui.adapter.baseadapter.BaseRecyclerViewAdapter;

/**
 * Created by pengfengwang on 2017/1/16.
 */
public class SkinLibAdapter extends BaseRecyclerViewAdapter {
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

    }
}
