package com.ximsfei.skindemo.ui.discover;

import com.ximsfei.skindemo.R;
import com.ximsfei.skindemo.databinding.FragmentRadioBinding;
import com.ximsfei.skindemo.ui.base.BaseFragment;

/**
 * Created by ximsfei on 17-1-8.
 */

public class RadioFragment extends BaseFragment<FragmentRadioBinding> {
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_radio;
    }

    @Override
    protected void loadData() {

    }
}
