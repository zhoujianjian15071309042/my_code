package com.ximsfei.skindemo.ui.adapter;

import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import com.ximsfei.skindemo.bean.RecommendItem;
import com.ximsfei.skindemo.ui.adapter.baseadapter.BaseRecyclerViewAdapter;

/**
 * Created by ximsfei on 17-1-15.
 */
public class SongMenuAdapter extends BaseRecyclerViewAdapter {
    public SongMenuAdapter(Context context) {
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

    }
}
