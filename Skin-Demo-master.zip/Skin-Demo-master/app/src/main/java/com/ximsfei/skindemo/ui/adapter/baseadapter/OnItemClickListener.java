package com.ximsfei.skindemo.ui.adapter.baseadapter;

/**
 * Created by ximsfei on 2017/1/15.
 */
public interface OnItemClickListener<T> {
    public void onClick(T t, int position);
}
