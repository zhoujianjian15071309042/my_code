package com.ximsfei.skindemo.ui.friends;

import com.ximsfei.skindemo.R;
import com.ximsfei.skindemo.ui.base.BaseFragment;

/**
 * Created by ximsfei on 17-1-8.
 */

public class ContactsFragment extends BaseFragment {
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_contacts;
    }

    @Override
    protected void loadData() {

    }
}
