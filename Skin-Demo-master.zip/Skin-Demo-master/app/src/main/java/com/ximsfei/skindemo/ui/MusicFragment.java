package com.ximsfei.skindemo.ui;

import com.ximsfei.skindemo.R;
import com.ximsfei.skindemo.databinding.FragmentMusicBinding;
import com.ximsfei.skindemo.ui.base.BaseFragment;

/**
 * Created by ximsfei on 17-1-7.
 */

public class MusicFragment extends BaseFragment<FragmentMusicBinding> {
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_music;
    }

    @Override
    protected void loadData() {

    }
}
