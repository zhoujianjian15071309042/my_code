package com.ximsfei.skindemo.ui.discover;

import com.ximsfei.skindemo.R;
import com.ximsfei.skindemo.databinding.FragmentRankingBinding;
import com.ximsfei.skindemo.ui.base.BaseFragment;

/**
 * Created by ximsfei on 17-1-8.
 */

public class RankingFragment extends BaseFragment<FragmentRankingBinding> {
    @Override
    protected int getLayoutId() {
        return R.layout.fragment_ranking;
    }

    @Override
    protected void loadData() {

    }
}
