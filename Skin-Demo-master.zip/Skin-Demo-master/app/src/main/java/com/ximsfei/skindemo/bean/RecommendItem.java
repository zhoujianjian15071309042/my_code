package com.ximsfei.skindemo.bean;

/**
 * Created by pengfengwang on 2017/1/15.
 */

public class RecommendItem {
    public String title;
    public int indicator;

    public ImageItem item0;
    public ImageItem item1;
    public ImageItem item2;
    public ImageItem item3;
    public ImageItem item4;
    public ImageItem item5;
}
