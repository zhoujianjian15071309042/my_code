# Skin-Demo

## 介绍

[app](app) // 仿网易云音乐UI 官方红

[skin-night](skin-night) // 夜间模式皮肤包

[skin-white](skin-white) // 官方白皮肤包

[换肤框架实现](https://github.com/ximsfei/Android-skin-support)

下载[demo apk](https://github.com/ximsfei/Res/blob/master/skin-demo/app-debug.apk)

![red 1](https://github.com/ximsfei/Res/blob/master/skin-demo/red_1.png)
![red 2](https://github.com/ximsfei/Res/blob/master/skin-demo/red_2.png)
![red 3](https://github.com/ximsfei/Res/blob/master/skin-demo/red_3.png)

![white 1](https://github.com/ximsfei/Res/blob/master/skin-demo/white_1.png)
![white 2](https://github.com/ximsfei/Res/blob/master/skin-demo/white_2.png)
![white 3](https://github.com/ximsfei/Res/blob/master/skin-demo/white_3.png)

![night 1](https://github.com/ximsfei/Res/blob/master/skin-demo/night_1.png)
![night 2](https://github.com/ximsfei/Res/blob/master/skin-demo/night_2.png)
![night 3](https://github.com/ximsfei/Res/blob/master/skin-demo/night_3.png)

## UI参考: 网易云音乐App、[CloudReader](https://github.com/youlookwhat/CloudReader)、[banya](https://github.com/forezp/banya)
